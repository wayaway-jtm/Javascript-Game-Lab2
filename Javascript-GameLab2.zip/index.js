/*
 * John McCarthy
 * Javascript Game Lab 2
 */
fight("Adam", "Mitch", 100, 100);